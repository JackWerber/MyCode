﻿namespace _APIExConnector
{
	partial class FormMain
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.cbPersist = new System.Windows.Forms.CheckBox();
			this.btStopCollect = new System.Windows.Forms.Button();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.dgvExchange = new System.Windows.Forms.DataGridView();
			this.intExchangeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.cbEnable = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.txtExchange = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.dgvMethod = new System.Windows.Forms.DataGridView();
			this.ApiMethodID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Enable = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.ApiMethod = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.dgvParams = new System.Windows.Forms.DataGridView();
			this.ParamID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Key = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Value = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.button2 = new System.Windows.Forms.Button();
			this.btCollect = new System.Windows.Forms.Button();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.tabControl2 = new System.Windows.Forms.TabControl();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.btOthProcLaunch = new System.Windows.Forms.Button();
			this.LabelOtherProcNam = new System.Windows.Forms.Label();
			this.cbOthProcList = new System.Windows.Forms.ComboBox();
			this.button3 = new System.Windows.Forms.Button();
			this.tbOthProcOutput = new System.Windows.Forms.TextBox();
			this.btOthProcInput = new System.Windows.Forms.Button();
			this.LabelOthProcOut = new System.Windows.Forms.Label();
			this.LabelOthProcInp = new System.Windows.Forms.Label();
			this.tbOthProcInput = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.grMethod = new System.Windows.Forms.GroupBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.groupBoxLog = new System.Windows.Forms.GroupBox();
			this.richTextBoxLog = new System.Windows.Forms.RichTextBox();
			this.btClearLog = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvExchange)).BeginInit();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvMethod)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvParams)).BeginInit();
			this.tabPage2.SuspendLayout();
			this.tabControl2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.grMethod.SuspendLayout();
			this.groupBoxLog.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Location = new System.Drawing.Point(12, 12);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(466, 572);
			this.tabControl1.TabIndex = 4;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.cbPersist);
			this.tabPage1.Controls.Add(this.btStopCollect);
			this.tabPage1.Controls.Add(this.groupBox3);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Controls.Add(this.groupBox2);
			this.tabPage1.Controls.Add(this.groupBox1);
			this.tabPage1.Controls.Add(this.button2);
			this.tabPage1.Controls.Add(this.btCollect);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(458, 546);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "API data collector";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// cbPersist
			// 
			this.cbPersist.AutoSize = true;
			this.cbPersist.Location = new System.Drawing.Point(238, 519);
			this.cbPersist.Name = "cbPersist";
			this.cbPersist.Size = new System.Drawing.Size(71, 17);
			this.cbPersist.TabIndex = 7;
			this.cbPersist.Text = "persistent";
			this.cbPersist.UseVisualStyleBackColor = true;
			this.cbPersist.CheckedChanged += new System.EventHandler(this.cbPersist_CheckedChanged);
			// 
			// btStopCollect
			// 
			this.btStopCollect.Enabled = false;
			this.btStopCollect.Location = new System.Drawing.Point(315, 515);
			this.btStopCollect.Name = "btStopCollect";
			this.btStopCollect.Size = new System.Drawing.Size(45, 23);
			this.btStopCollect.TabIndex = 6;
			this.btStopCollect.Text = "Stop";
			this.btStopCollect.UseVisualStyleBackColor = true;
			this.btStopCollect.Click += new System.EventHandler(this.btStopCollect_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.dgvExchange);
			this.groupBox3.Location = new System.Drawing.Point(6, 32);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(446, 136);
			this.groupBox3.TabIndex = 5;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Exchange";
			// 
			// dgvExchange
			// 
			this.dgvExchange.AllowUserToAddRows = false;
			this.dgvExchange.AllowUserToDeleteRows = false;
			this.dgvExchange.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvExchange.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.intExchangeID,
            this.cbEnable,
            this.txtExchange});
			this.dgvExchange.Location = new System.Drawing.Point(7, 15);
			this.dgvExchange.Name = "dgvExchange";
			this.dgvExchange.Size = new System.Drawing.Size(433, 115);
			this.dgvExchange.TabIndex = 0;
			// 
			// intExchangeID
			// 
			this.intExchangeID.DataPropertyName = "ExchangeID";
			this.intExchangeID.HeaderText = "Exchange ID";
			this.intExchangeID.Name = "intExchangeID";
			this.intExchangeID.Visible = false;
			// 
			// cbEnable
			// 
			this.cbEnable.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
			this.cbEnable.DataPropertyName = "Enable";
			this.cbEnable.HeaderText = "Enable";
			this.cbEnable.MinimumWidth = 35;
			this.cbEnable.Name = "cbEnable";
			this.cbEnable.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.cbEnable.Width = 46;
			// 
			// txtExchange
			// 
			this.txtExchange.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.txtExchange.DataPropertyName = "Exchange";
			this.txtExchange.HeaderText = "Exchange";
			this.txtExchange.Name = "txtExchange";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(10, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(285, 13);
			this.label1.TabIndex = 4;
			this.label1.Text = "Choose methods, set parameters amd press Start collecting";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.dgvMethod);
			this.groupBox2.Location = new System.Drawing.Point(6, 171);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(446, 136);
			this.groupBox2.TabIndex = 3;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Method";
			// 
			// dgvMethod
			// 
			this.dgvMethod.AllowUserToAddRows = false;
			this.dgvMethod.AllowUserToDeleteRows = false;
			this.dgvMethod.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvMethod.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ApiMethodID,
            this.Enable,
            this.ApiMethod});
			this.dgvMethod.Location = new System.Drawing.Point(6, 14);
			this.dgvMethod.Name = "dgvMethod";
			this.dgvMethod.Size = new System.Drawing.Size(433, 116);
			this.dgvMethod.TabIndex = 0;
			// 
			// ApiMethodID
			// 
			this.ApiMethodID.DataPropertyName = "ApiMethodID";
			this.ApiMethodID.HeaderText = "Api Method ID";
			this.ApiMethodID.Name = "ApiMethodID";
			this.ApiMethodID.Visible = false;
			// 
			// Enable
			// 
			this.Enable.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
			this.Enable.DataPropertyName = "Enable";
			this.Enable.HeaderText = "Enable";
			this.Enable.MinimumWidth = 35;
			this.Enable.Name = "Enable";
			this.Enable.Width = 46;
			// 
			// ApiMethod
			// 
			this.ApiMethod.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.ApiMethod.DataPropertyName = "ApiMethod";
			this.ApiMethod.HeaderText = "API Method";
			this.ApiMethod.Name = "ApiMethod";
			this.ApiMethod.Width = 344;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.dgvParams);
			this.groupBox1.Location = new System.Drawing.Point(6, 313);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(446, 198);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Parameters";
			// 
			// dgvParams
			// 
			this.dgvParams.AllowUserToAddRows = false;
			this.dgvParams.AllowUserToDeleteRows = false;
			this.dgvParams.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvParams.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ParamID,
            this.Key,
            this.Value});
			this.dgvParams.Location = new System.Drawing.Point(6, 14);
			this.dgvParams.Name = "dgvParams";
			this.dgvParams.Size = new System.Drawing.Size(434, 178);
			this.dgvParams.TabIndex = 0;
			// 
			// ParamID
			// 
			this.ParamID.DataPropertyName = "ParamID";
			this.ParamID.HeaderText = "Parameter ID";
			this.ParamID.Name = "ParamID";
			this.ParamID.Visible = false;
			// 
			// Key
			// 
			this.Key.DataPropertyName = "Key";
			this.Key.HeaderText = "Key";
			this.Key.MinimumWidth = 75;
			this.Key.Name = "Key";
			this.Key.Width = 75;
			// 
			// Value
			// 
			this.Value.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Value.DataPropertyName = "Value";
			this.Value.HeaderText = "Value";
			this.Value.Name = "Value";
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(6, 515);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(122, 23);
			this.button2.TabIndex = 1;
			this.button2.Text = "Settings";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// btCollect
			// 
			this.btCollect.Location = new System.Drawing.Point(366, 515);
			this.btCollect.Name = "btCollect";
			this.btCollect.Size = new System.Drawing.Size(86, 23);
			this.btCollect.TabIndex = 1;
			this.btCollect.Text = "Collect";
			this.btCollect.UseVisualStyleBackColor = true;
			this.btCollect.Click += new System.EventHandler(this.btCollect_Click);
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.tabControl2);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(458, 546);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Other";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// tabControl2
			// 
			this.tabControl2.Controls.Add(this.tabPage3);
			this.tabControl2.Location = new System.Drawing.Point(6, 6);
			this.tabControl2.Name = "tabControl2";
			this.tabControl2.SelectedIndex = 0;
			this.tabControl2.Size = new System.Drawing.Size(446, 534);
			this.tabControl2.TabIndex = 1;
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.btOthProcLaunch);
			this.tabPage3.Controls.Add(this.LabelOtherProcNam);
			this.tabPage3.Controls.Add(this.cbOthProcList);
			this.tabPage3.Controls.Add(this.button3);
			this.tabPage3.Controls.Add(this.tbOthProcOutput);
			this.tabPage3.Controls.Add(this.btOthProcInput);
			this.tabPage3.Controls.Add(this.LabelOthProcOut);
			this.tabPage3.Controls.Add(this.LabelOthProcInp);
			this.tabPage3.Controls.Add(this.tbOthProcInput);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage3.Size = new System.Drawing.Size(438, 508);
			this.tabPage3.TabIndex = 0;
			this.tabPage3.Text = "Process file";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// btOthProcLaunch
			// 
			this.btOthProcLaunch.Location = new System.Drawing.Point(319, 127);
			this.btOthProcLaunch.Name = "btOthProcLaunch";
			this.btOthProcLaunch.Size = new System.Drawing.Size(113, 23);
			this.btOthProcLaunch.TabIndex = 12;
			this.btOthProcLaunch.Text = "Launch";
			this.btOthProcLaunch.UseVisualStyleBackColor = true;
			this.btOthProcLaunch.Click += new System.EventHandler(this.btOthProcLaunch_Click);
			// 
			// LabelOtherProcNam
			// 
			this.LabelOtherProcNam.AutoSize = true;
			this.LabelOtherProcNam.Location = new System.Drawing.Point(6, 113);
			this.LabelOtherProcNam.Name = "LabelOtherProcNam";
			this.LabelOtherProcNam.Size = new System.Drawing.Size(45, 13);
			this.LabelOtherProcNam.TabIndex = 11;
			this.LabelOtherProcNam.Text = "Process";
			// 
			// cbOthProcList
			// 
			this.cbOthProcList.FormattingEnabled = true;
			this.cbOthProcList.Location = new System.Drawing.Point(9, 129);
			this.cbOthProcList.Name = "cbOthProcList";
			this.cbOthProcList.Size = new System.Drawing.Size(208, 21);
			this.cbOthProcList.TabIndex = 10;
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(378, 77);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(54, 23);
			this.button3.TabIndex = 4;
			this.button3.Text = "Choose";
			this.button3.UseVisualStyleBackColor = true;
			// 
			// tbOthProcOutput
			// 
			this.tbOthProcOutput.Location = new System.Drawing.Point(9, 79);
			this.tbOthProcOutput.Name = "tbOthProcOutput";
			this.tbOthProcOutput.Size = new System.Drawing.Size(363, 20);
			this.tbOthProcOutput.TabIndex = 3;
			// 
			// btOthProcInput
			// 
			this.btOthProcInput.Location = new System.Drawing.Point(378, 27);
			this.btOthProcInput.Name = "btOthProcInput";
			this.btOthProcInput.Size = new System.Drawing.Size(54, 23);
			this.btOthProcInput.TabIndex = 2;
			this.btOthProcInput.Text = "Browse";
			this.btOthProcInput.UseVisualStyleBackColor = true;
			this.btOthProcInput.Click += new System.EventHandler(this.btOthProcInput_Click);
			// 
			// LabelOthProcOut
			// 
			this.LabelOthProcOut.AutoSize = true;
			this.LabelOthProcOut.Location = new System.Drawing.Point(6, 63);
			this.LabelOthProcOut.Name = "LabelOthProcOut";
			this.LabelOthProcOut.Size = new System.Drawing.Size(39, 13);
			this.LabelOthProcOut.TabIndex = 1;
			this.LabelOthProcOut.Text = "Output";
			// 
			// LabelOthProcInp
			// 
			this.LabelOthProcInp.AutoSize = true;
			this.LabelOthProcInp.Location = new System.Drawing.Point(6, 13);
			this.LabelOthProcInp.Name = "LabelOthProcInp";
			this.LabelOthProcInp.Size = new System.Drawing.Size(31, 13);
			this.LabelOthProcInp.TabIndex = 1;
			this.LabelOthProcInp.Text = "Input";
			// 
			// tbOthProcInput
			// 
			this.tbOthProcInput.Location = new System.Drawing.Point(9, 29);
			this.tbOthProcInput.Name = "tbOthProcInput";
			this.tbOthProcInput.Size = new System.Drawing.Size(363, 20);
			this.tbOthProcInput.TabIndex = 0;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(845, 22);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(46, 25);
			this.button1.TabIndex = 5;
			this.button1.Text = "Get";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// grMethod
			// 
			this.grMethod.Controls.Add(this.comboBox1);
			this.grMethod.Location = new System.Drawing.Point(534, 12);
			this.grMethod.Name = "grMethod";
			this.grMethod.Size = new System.Drawing.Size(305, 40);
			this.grMethod.TabIndex = 4;
			this.grMethod.TabStop = false;
			this.grMethod.Text = "Test methods";
			// 
			// comboBox1
			// 
			this.comboBox1.Items.AddRange(new object[] {
            "/public/get_time",
            "/public/get_order_book",
            "/public/get_tradingview_chart_data",
            "/public/get_last_trades_by_instrument_and_time"});
			this.comboBox1.Location = new System.Drawing.Point(6, 13);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(293, 21);
			this.comboBox1.TabIndex = 0;
			// 
			// groupBoxLog
			// 
			this.groupBoxLog.Controls.Add(this.richTextBoxLog);
			this.groupBoxLog.Location = new System.Drawing.Point(484, 58);
			this.groupBoxLog.Name = "groupBoxLog";
			this.groupBoxLog.Size = new System.Drawing.Size(407, 529);
			this.groupBoxLog.TabIndex = 5;
			this.groupBoxLog.TabStop = false;
			this.groupBoxLog.Text = "Log";
			// 
			// richTextBoxLog
			// 
			this.richTextBoxLog.BackColor = System.Drawing.SystemColors.MenuText;
			this.richTextBoxLog.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.richTextBoxLog.ForeColor = System.Drawing.SystemColors.Window;
			this.richTextBoxLog.Location = new System.Drawing.Point(8, 17);
			this.richTextBoxLog.Margin = new System.Windows.Forms.Padding(0);
			this.richTextBoxLog.Name = "richTextBoxLog";
			this.richTextBoxLog.ReadOnly = true;
			this.richTextBoxLog.Size = new System.Drawing.Size(393, 509);
			this.richTextBoxLog.TabIndex = 1;
			this.richTextBoxLog.Text = "";
			// 
			// btClearLog
			// 
			this.btClearLog.Location = new System.Drawing.Point(484, 22);
			this.btClearLog.Name = "btClearLog";
			this.btClearLog.Size = new System.Drawing.Size(44, 25);
			this.btClearLog.TabIndex = 6;
			this.btClearLog.Text = "Clear";
			this.btClearLog.UseVisualStyleBackColor = true;
			this.btClearLog.Click += new System.EventHandler(this.BtClearLog_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// FormMain
			// 
			this.AcceptButton = this.btCollect;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(897, 609);
			this.Controls.Add(this.btClearLog);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.groupBoxLog);
			this.Controls.Add(this.grMethod);
			this.Controls.Add(this.tabControl1);
			this.DoubleBuffered = true;
			this.MaximizeBox = false;
			this.Name = "FormMain";
			this.Text = "CryptoExchange API collector";
			this.Load += new System.EventHandler(this.FormMain_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgvExchange)).EndInit();
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgvMethod)).EndInit();
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgvParams)).EndInit();
			this.tabPage2.ResumeLayout(false);
			this.tabControl2.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			this.tabPage3.PerformLayout();
			this.grMethod.ResumeLayout(false);
			this.groupBoxLog.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		public System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.DataGridView dgvMethod;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.DataGridView dgvParams;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button btCollect;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.DataGridView dgvExchange;
		private System.Windows.Forms.DataGridViewTextBoxColumn intExchangeID;
		private System.Windows.Forms.DataGridViewCheckBoxColumn cbEnable;
		private System.Windows.Forms.DataGridViewTextBoxColumn txtExchange;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.GroupBox grMethod;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.GroupBox groupBoxLog;
		private System.Windows.Forms.RichTextBox richTextBoxLog;
		private System.Windows.Forms.DataGridViewTextBoxColumn ApiMethodID;
		private System.Windows.Forms.DataGridViewCheckBoxColumn Enable;
		private System.Windows.Forms.DataGridViewTextBoxColumn ApiMethod;
		private System.Windows.Forms.DataGridViewTextBoxColumn ParamID;
		private System.Windows.Forms.DataGridViewTextBoxColumn Key;
		private System.Windows.Forms.DataGridViewTextBoxColumn Value;
		private System.Windows.Forms.Button btStopCollect;
		private System.Windows.Forms.CheckBox cbPersist;
		private System.Windows.Forms.Button btClearLog;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.TextBox tbOthProcInput;
		private System.Windows.Forms.TabControl tabControl2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.Label LabelOthProcInp;
		private System.Windows.Forms.Label LabelOthProcOut;
		private System.Windows.Forms.Button btOthProcInput;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.TextBox tbOthProcOutput;
		private System.Windows.Forms.Label LabelOtherProcNam;
		private System.Windows.Forms.ComboBox cbOthProcList;
		private System.Windows.Forms.Button btOthProcLaunch;
	}
}

