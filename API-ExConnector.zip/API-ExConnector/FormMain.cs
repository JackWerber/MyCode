﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp.Extensions;

namespace _APIExConnector
{
	public partial class FormMain : Form
	{
		FormSettings oFormSettings = (FormSettings)Application.OpenForms["FormSettings"];

		public FormMain()
		{
			InitializeComponent();
			this.Shown += new System.EventHandler(this.FormMain_Shown);
			FormMainLogAppend.EventHandler = LogAppendRichText;
			FormMainBtStopCollect.EventHandler = StopCollectEvt;
		}
		class OthProcIDropDowntems
		{
			public string name { get; set; }
			public Action action { get; set; }
			public override string ToString() { return name; }
		}

		private void LogAppendRichText(string textToLog)
		{
			this.BeginInvoke((MethodInvoker)delegate {
				richTextBoxLog.AppendText(DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss") + " > " + textToLog + "\r\n\r\n");
				richTextBoxLog.ScrollToCaret();
			});
		}

		private void FIllFormParams()
		{
			comboBox1.SelectedIndex = 0;
			dgvExchange.DataSource = ConfigPreLoad.tableDgvExchange;
			dgvMethod.DataSource = ConfigPreLoad.tableDgvMethod;
			dgvParams.DataSource = ConfigPreLoad.tableDgvParams;

			cbPersist.Checked = ConfigPreLoad.modeCollectPersistent;
			if (cbPersist.Checked)
				cbPersist.CheckState = System.Windows.Forms.CheckState.Checked;
			else
				cbPersist.CheckState = System.Windows.Forms.CheckState.Unchecked;

            cbOthProcList.Items.Add("None");
			/*foreach (var othProcMethod in OthProc.OthProcMethods)
			{
				cbOthProcList.Items.Add(new OthProcIDropDowntems { name = othProcMethod.Value.ToString, action = () =>
                {
                    MessageBox.Show("Test");
                } });
			}*/
			FormMainLogAppend.EventHandler("application started");
		}
		private void FormMain_Load(object sender, EventArgs e)
		{
			this.BeginInvoke((MethodInvoker)delegate {
				this.FormBorderStyle = FormBorderStyle.FixedSingle;
                FIllFormParams();
				cbOthProcList.SelectedIndex = 0;
            });
		}
		private void FormMain_Shown(Object sender, EventArgs e)
		{
			//DateTime tmp = DateTime.UtcNow;
			//richTextBoxLog.Text = "The stamp is now: " + Program.ConvDateToStamp(tmp, true) + "\r\n" +
			//                    "The time is now:  " + Program.ConvStampToDateString(Program.ConvDateToStamp(tmp, true), true) + "\r\n\r\n";
		}

		private void Button1_Click(object sender, EventArgs e)
		{
			if (comboBox1.Text == "/public/get_time")
				Program.TestApiGetTimeGet();
			else if (comboBox1.Text == "/public/get_order_book")
				Program.TestPublicGetOrderBookGet();
			else if (comboBox1.Text == "/public/get_tradingview_chart_data")
				Program.TestPublicGetTradingviewChartDataGet();
			else if (comboBox1.Text == "/public/get_last_trades_by_instrument_and_time")
				Program.TestPublicGetLastTradesByInstrumentAndTimeGet();
			else
				MessageBox.Show("No request bound to this method :\r\n" + comboBox1.Text);
			//GetApiResult ApiResult = new GetApiResult();
			LogAppendRichText(GetApiResult.ResultText); // InitSettings.iniGeneralFile;
		}
		private void button2_Click(object sender, EventArgs e)
		{
			if (oFormSettings == null) // Если форма не существует, то создаём
			{
				FormSettings settingsForm = new FormSettings();
				settingsForm.FormSettingsEvtEnableButtonSettings += new FormSettingsShow(SetButtonSettingsEnabled);
				settingsForm.Show(this);
				button2.Enabled = false;
			}
			else
				oFormSettings.Activate();
		}
		public void SetButtonSettingsEnabled() { button2.Enabled = true; }

		private void btCollect_Click(object sender, EventArgs e)
		{
			btStopCollect.Enabled = true;
			btCollect.Enabled = false;
			Program.ScenarioCollect();
		}

		private void StopCollectEvt()
		{
			btStopCollect.Enabled = false;
			btCollect.Enabled = true;
		}
		private void btStopCollect_Click(object sender, EventArgs e)
		{
			btStopCollect.Enabled = false;
			btCollect.Enabled = true;
			Program.ScenarioStopCollect("requested terminate");
		}

		private void cbPersist_CheckedChanged(object sender, EventArgs e)
		{
			if (cbPersist.Checked)
				ConfigPreLoad.modeCollectPersistent = true;
			else
				ConfigPreLoad.modeCollectPersistent = false;
		}

		private void BtClearLog_Click(object sender, EventArgs e)
		{
			this.BeginInvoke((MethodInvoker)delegate {
				richTextBoxLog.Text = "";
			});
		}

		private void btOthProcInput_Click(object sender, EventArgs e)
		{
			openFileDialog1.InitialDirectory = "G:\\";
			openFileDialog1.RestoreDirectory = true;
			openFileDialog1.ShowDialog();
			if (openFileDialog1.FileName != null)
			{
				tbOthProcInput.Text = openFileDialog1.FileName;
			}
		}

		private void btOthProcLaunch_Click(object sender, EventArgs e)
		{

		}
	}
}
