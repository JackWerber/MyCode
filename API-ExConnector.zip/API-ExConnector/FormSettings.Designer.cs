﻿namespace _APIExConnector
{
	partial class FormSettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.dgvExchange = new System.Windows.Forms.DataGridView();
			this.intSettingSqlID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.txtKey = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.txtValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.dgvAPIConnection = new System.Windows.Forms.DataGridView();
			this.intSettingApiID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvExchange)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvAPIConnection)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.dgvExchange);
			this.groupBox3.Location = new System.Drawing.Point(8, 62);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(446, 133);
			this.groupBox3.TabIndex = 6;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Settings for connection";
			// 
			// dgvExchange
			// 
			this.dgvExchange.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvExchange.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.intSettingSqlID,
            this.txtKey,
            this.txtValue});
			this.dgvExchange.Location = new System.Drawing.Point(7, 15);
			this.dgvExchange.Name = "dgvExchange";
			this.dgvExchange.Size = new System.Drawing.Size(433, 112);
			this.dgvExchange.TabIndex = 0;
			this.dgvExchange.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvExchange_CellFormatting);
			this.dgvExchange.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvExchange_EditingControlShowing);
			// 
			// intSettingSqlID
			// 
			this.intSettingSqlID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
			this.intSettingSqlID.DataPropertyName = "SettingSqlID";
			this.intSettingSqlID.HeaderText = "Setting SQL ID";
			this.intSettingSqlID.Name = "intSettingSqlID";
			this.intSettingSqlID.Visible = false;
			// 
			// txtKey
			// 
			this.txtKey.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.txtKey.DataPropertyName = "Key";
			this.txtKey.HeaderText = "Key";
			this.txtKey.Name = "txtKey";
			// 
			// txtValue
			// 
			this.txtValue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.txtValue.DataPropertyName = "Value";
			this.txtValue.HeaderText = "Value";
			this.txtValue.Name = "txtValue";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.dgvAPIConnection);
			this.groupBox1.Location = new System.Drawing.Point(8, 242);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(446, 133);
			this.groupBox1.TabIndex = 7;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Settings for API connection";
			// 
			// dgvAPIConnection
			// 
			this.dgvAPIConnection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvAPIConnection.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.intSettingApiID,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
			this.dgvAPIConnection.Location = new System.Drawing.Point(7, 15);
			this.dgvAPIConnection.Name = "dgvAPIConnection";
			this.dgvAPIConnection.Size = new System.Drawing.Size(433, 112);
			this.dgvAPIConnection.TabIndex = 0;
			// 
			// intSettingApiID
			// 
			this.intSettingApiID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
			this.intSettingApiID.DataPropertyName = "SettingApiID";
			this.intSettingApiID.HeaderText = "Setting API ID";
			this.intSettingApiID.Name = "intSettingApiID";
			this.intSettingApiID.Visible = false;
			// 
			// dataGridViewTextBoxColumn2
			// 
			this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn2.DataPropertyName = "Key";
			this.dataGridViewTextBoxColumn2.HeaderText = "Key";
			this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			// 
			// dataGridViewTextBoxColumn3
			// 
			this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn3.DataPropertyName = "Value";
			this.dataGridViewTextBoxColumn3.HeaderText = "Value";
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 195);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(151, 23);
			this.button1.TabIndex = 8;
			this.button1.Text = "Check SQL connection";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(8, 375);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(151, 23);
			this.button2.TabIndex = 8;
			this.button2.Text = "Check API connection";
			this.button2.UseVisualStyleBackColor = true;
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
            "File",
            "MSSQL"});
			this.comboBox1.Location = new System.Drawing.Point(15, 25);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(208, 21);
			this.comboBox1.TabIndex = 9;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(134, 13);
			this.label1.TabIndex = 10;
			this.label1.Text = "Select DB connection type";
			// 
			// FormSettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(457, 410);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.groupBox3);
			this.MaximizeBox = false;
			this.Name = "FormSettings";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Connection settings";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormSettings_FormClosing);
			this.Load += new System.EventHandler(this.FormSettings_Load);
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgvExchange)).EndInit();
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgvAPIConnection)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.DataGridView dgvAPIConnection;
		private System.Windows.Forms.DataGridView dgvExchange;
		private System.Windows.Forms.DataGridViewTextBoxColumn intSettingSqlID;
		private System.Windows.Forms.DataGridViewTextBoxColumn txtKey;
		private System.Windows.Forms.DataGridViewTextBoxColumn txtValue;
		private System.Windows.Forms.DataGridViewTextBoxColumn intSettingApiID;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label1;
	}
}