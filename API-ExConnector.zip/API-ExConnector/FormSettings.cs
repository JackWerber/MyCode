﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Data.SqlClient;

namespace _APIExConnector
{
	public delegate void FormSettingsShow();

	public partial class FormSettings : Form
	{
		public class InitSettingsFromFile
		{
			public static string iniGeneralFile = File.ReadAllText(@".\iniGeneral.json");
			public static Dictionary<string, string> iniGeneralDic = JsonConvert.DeserializeObject<Dictionary<string, string>>(iniGeneralFile);

			public static Dictionary<string, string> DictIniSettingsDefaultSql;
			public static Dictionary<string, string> DictIniSettingsSql;
			public void IniSettingsSqlDefaultToDict()
			{
				DictIniSettingsDefaultSql.Add("type", "MSSQL");
				DictIniSettingsDefaultSql.Add("server", "local");
				DictIniSettingsDefaultSql.Add("instance", "");
				DictIniSettingsDefaultSql.Add("DBname", "ExAPIdata");
				DictIniSettingsDefaultSql.Add("SecInt", "true");
			}

			public string IniConvertSettingsSqlToString()
			{
				if (DictIniSettingsSql.Count == 0)
					DictIniSettingsSql = DictIniSettingsDefaultSql;
				string conn_string = @"";
				switch (DictIniSettingsSql["type"])
				{
					case "MSSQL":
						return conn_string += String.Format("Data Source=({0}){1}; Initial Catalog ={2}; Integrated Security={3}",
							DictIniSettingsSql["server"],
							DictIniSettingsSql["instance"],
							DictIniSettingsSql["DBname"],
							DictIniSettingsSql["SecInt"]);
					default:
						return "error";
				}
			}
			void PopulateIniSettingsSql()
			{
				string AdapterSelect = IniConvertSettingsSqlToString();
				if (AdapterSelect == "error")
				{
					MessageBox.Show("Critical error in SQL settings in the iniGeneral file. Please fix the SQL type");
					return;
				}
					
				using (SqlConnection sqlCon = new SqlConnection(AdapterSelect))
				{
					SqlDataAdapter SqlDA = new SqlDataAdapter(AdapterSelect, sqlCon);
					DataTable dtbSqlSettings = new DataTable();
					SqlDA.Fill(dtbSqlSettings);
				}
			}

			
		}
		private void dgvExchange_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			var vCurrentCell = dgvExchange.CurrentCell;
			object vKeyCellValue = dgvExchange[vCurrentCell.ColumnIndex, vCurrentCell.RowIndex].Value;
			if (vKeyCellValue is null) return;

			if (e.ColumnIndex == 2 && e.Value != null) {
				if (dgvExchange.Rows[e.RowIndex].Cells[e.ColumnIndex - 1].Value.ToString().ToLower().Contains("password") ||
				    dgvExchange.Rows[e.RowIndex].Cells[e.ColumnIndex - 1].Value.ToString().ToLower().Contains("secret"))
				{
					dgvExchange.Rows[e.RowIndex].Tag = e.Value;
					e.Value = new String('\u25CF', 12);
					e.FormattingApplied = true;
				}
			}
		}
		private void dgvExchange_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
		{
			TextBox textBox = e.Control as TextBox;
			if (dgvExchange.CurrentCell.ColumnIndex == 2)
			{
				var vCurrentCell = dgvExchange.CurrentCell;
				object oKeyCellValue = dgvExchange[vCurrentCell.ColumnIndex - 1, vCurrentCell.RowIndex].Value;
				if (oKeyCellValue is null) 
					return;
				if (textBox != null && oKeyCellValue.ToString().ToLower().Contains("password") ||
						oKeyCellValue.ToString().ToLower().Contains("secret")) textBox.UseSystemPasswordChar = true;
			}
			else
			{
				if (textBox != null) 
					textBox.UseSystemPasswordChar = false;
			}
			//textBox.KeyDown -= new KeyEventHandler(underlyingTextBox_KeyDown);
			//textBox.KeyDown += new KeyEventHandler(underlyingTextBox_KeyDown);
		}

		void underlyingTextBox_KeyDown(object sender, KeyEventArgs e)
		{
			//MessageBox.Show("test lol");
			//dgvExchange_EditingControlShowing(sender, e);
		}

		//void dgvExchange_CellBeginEdit(Object sender, DataGridViewCellCancelEventArgs e)
		//{
		//dgvExchange_EditingControlShowing(sender, e);
		//}
		public event FormSettingsShow FormSettingsEvtEnableButtonSettings;

		private void FormSettings_FormClosing(object sender, EventArgs e)
		{
			FormSettingsEvtEnableButtonSettings();
			this.Close();
			//FormMain.SetButtonSettingsEnabled(true);
		}
		private void FormSettings_Load(object sender, EventArgs e)
		{
			this.BeginInvoke((MethodInvoker)delegate {
				this.FormBorderStyle = FormBorderStyle.FixedSingle;
				comboBox1.SelectedIndex = 0;
			});
		}
		public FormSettings()
		{
			InitializeComponent();
		}
	}
}
