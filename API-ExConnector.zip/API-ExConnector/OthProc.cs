﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _APIExConnector
{
	class OthProc
	{
		public string OthProcInput = null;
		public string OthProcOutput = null; 
		public string name { get; set; }
		public Action action { get; set; }

		public static Dictionary<string, object> OthProcMethods
		{
			get => null;
			set { OthProcMethods.Add("Equalize bid-ask to last", ""); }
		}

		void Init()
		{
			
		}

		class EditBidAsc
		{
			
		}
	}
}
