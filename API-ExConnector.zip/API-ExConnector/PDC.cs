﻿using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Linq;

namespace _APIExConnector
{
	public class ModuleDataProtection
  {
		// If byte array was created like this:
		// byte[] bytes = Encoding.ASCII.GetBytes(someString);

		// You will need to turn it back into a string like this:
		// string someString = Encoding.ASCII.GetString(bytes);

		// To see byte as a raw string of digit pairs
		// BitConverter.ToString(secret)
		// From String to bytes array (x64 so not suitable here)
		// Encoding.UTF8.GetBytes(string)

    // Create byte array for additional entropy when using Protect method, do not change
    static readonly byte[] s_aditionalEntropy = { 5, 0, 4, 8, 2, 5, 3, 4, 2, 4, 7, 6, 4, 5, 8, 0, 0, 1, 0, 6, 6, 1, 1, 8, 1, 2, 3, 3, 2, 1, 7, 7, 8, 7, 6, 2, 6, 7, 5, 9, 2, 8, 1, 2, 3, 6, 8, 3, 0, 3 };

		public static string PDCEncrypt(string SecretData)
		{
			// Create a simple byte array containing data to be encrypted.
      byte[] secret = Encoding.UTF8.GetBytes(SecretData);
			//Encrypt the data.
			byte[] encryptedSecret = Protect(secret);
			return BitConverter.ToString(encryptedSecret);
		}

		public static string PDCDecrypt(string SecretData)
		{
			byte[] byteSecretData = GetBytesArray32(SecretData); // x64 is not suitable!
      // Decrypt the data and store in a byte array.
      byte[] originalData = Unprotect(byteSecretData);

			return Encoding.UTF8.GetString(originalData);
		}

		public static byte[] Protect(byte[] data)
    {
      try
      {
        // Encrypt the data using DataProtectionScope.CurrentUser. The result can be decrypted
        // only by the same current user.
        return ProtectedData.Protect(data, s_aditionalEntropy, DataProtectionScope.CurrentUser);
      }
      catch (CryptographicException e)
      {
        Console.WriteLine("Data was not encrypted. An error occurred.");
        Console.WriteLine(e.ToString());
        return null;
      }
    }

    public static byte[] Unprotect(byte[] data)
    {
      try
      {
        //Decrypt the data using DataProtectionScope.CurrentUser.
        return ProtectedData.Unprotect(data, s_aditionalEntropy, DataProtectionScope.LocalMachine);
      }
      catch (CryptographicException e)
      {
        Console.WriteLine("Data was not decrypted. An error occurred.");
        Console.WriteLine(e.ToString());
        return null;
      }
    }
    public static byte[] GetBytesArray32(string value)
    {
	    return value.Split('-').Select(s => byte.Parse(s, System.Globalization.NumberStyles.HexNumber)).ToArray();
    }

    public static void PrintValues(Byte[] myArr)
    {
      foreach (Byte i in myArr)
      {
        Console.Write("\t{0}", i);
      }
      Console.WriteLine();
    }
  }
}
