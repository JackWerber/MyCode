﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Globalization;
using System.Net.Mime;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using System.Reflection;
using System.Text;
using System.Threading;
using CsvHelper;
using CsvHelper.Configuration.Attributes;
using MiscUtil.IO;
using Newtonsoft.Json.Linq;

namespace _APIExConnector
{
	public class FormMainLogAppend
	{
		public delegate void EvtLogAppend(string data);
		public static EvtLogAppend EventHandler;
	}
	public class FormMainBtStopCollect
	{
		public delegate void EvtStopCollect();
		public static EvtStopCollect EventHandler;
	}

	public static class Collection
	{
		public static IEnumerable<string> GetKey(this JToken obj)
		{
			return ((JObject)obj).Children().Cast<JProperty>().Select(x => x.Name);
		}
	}
	public class StoreDataLastTradesByInstrumentAndTime
	{
		[Index(0)] public string date { get; set; }
		[Index(1)] public string timems { get; set; }
		[Index(2)] public string bid { get; set; }
		[Index(3)] public string ask { get; set; }
		[Index(4)] public string last { get; set; }
		[Index(5)] public string volume { get; set; }
		[Index(5)] public string flags { get; set; }
		[Index(6)] public string comment { get; set; }
		public StoreDataLastTradesByInstrumentAndTime(string[] data)
		{
			Action<string>[] PropertyMappings =
			{
				x=>this.date=x,
				x=>this.timems=x,
				x=>this.bid=x,
				x=>this.ask=x,
				x=>this.last=x,
				x=>this.volume=x,
				x=>this.flags=x,
				x=>this.comment=x,
			};
			for (int i = 0; i < data.Count(); i++)
			{
				PropertyMappings[i](data[i]);
			}
		}
	}

	public class ClassDeribitApiParams
	{
		public static MarketDataApi apiInstance = new MarketDataApi(Configuration.Default);
		public class LastTradesByInstrumentAndTime : ClassDeribitApiParams
		{
			public string instrumentName;  // string | Instrument name
			public long startTimestamp;  // long? | The earliest timestamp to return result for
			public long endTimestamp;  // long? | The most recent timestamp to return result for
			public int count;          // int? | Number of requested items, default - `10` (optional) 
			public bool includeOld;  // bool? | Include trades older than 7 days, default - `false` (optional) 
			public string sorting;  // string | Direction of results sorting (`default` value means no sorting, results will be returned in order in which they left the database) (optional) 

			public void SetVal(string instrumentName, string startTimestamp, string endTimestamp, string count, string includeOld, string sorting)
			{
				this.instrumentName = instrumentName;
				this.startTimestamp = Convert.ToInt64(startTimestamp);
				this.endTimestamp = Convert.ToInt64(endTimestamp);
				this.count = Convert.ToUInt16(count);
				this.includeOld = Convert.ToBoolean(includeOld);
				this.sorting = sorting;
			}
			public object Get(string instrumentName, long startTimestamp, long endTimestamp, int count, bool includeOld, string sorting)
			{
				try { return apiInstance.PublicGetLastTradesByInstrumentAndTimeGet(instrumentName, startTimestamp, endTimestamp, count, includeOld, sorting); }
				catch (ApiException e) { return e.Message; }
			}
		}
		public class LastTradesByInstrumentAndTimeResult
		{
			public class Data
			{
				public string jsonrpc { get; set; }
				public Result result { get; set; }
				public long usIn { get; set; }
				public long usOut { get; set; }
				public long usDiff { get; set; }
				public bool testnet { get; set; }
			}
			public class Result
			{ 
				public Trade[] trades { get; set; }
				public bool has_more { get; set; }
			}
			public class Trade
			{
				public long trade_seq { get; set; }
				public string trade_id { get; set; }
				public long timestamp { get; set; }
				public int tick_direction { get; set; }
				public double price { get; set; }
				public string instrument_name { get; set; }
				public double index_price { get; set; }
				public string direction { get; set; }
				public double amount { get; set; }
			}

			public class TradeOutput
			{
				private static string date;
				private static string timems;
				private static string bid;
				private static string ask;
				private static string last;
				private static string volume;
				private static string flags;
				private static string comment;

				public static string NewRow(Trade obj, string format)
				{
					var ci = new CultureInfo("en-US");
					string rowResult;
					date = Program.ConvStampToDateTimeMsString(obj.timestamp, "d");
					timems = Program.ConvStampToDateTimeMsString(obj.timestamp, "t");
					bid = (obj.direction == "buy" ? obj.price - 0.5 : obj.price).ToString("#0.00", ci);
					ask = (obj.direction == "sell" ? obj.price + 0.5 : obj.price).ToString("#0.00", ci);
					last = obj.price.ToString("#0.00", ci);
					volume = obj.amount.ToString();
					flags = obj.direction.ToString();
					comment = "artificial bid/ask";

					rowResult = $"{date};{timems};{bid};{ask};{last};{volume};{flags};{comment}";
					return rowResult;
				}
			}
		}

		public static void SetApiConfig()
		{
			Configuration.Default.BasePath = "https://www.deribit.com/api/v2";
			Configuration.Default.Username = "-ywvv13w";
			Configuration.Default.Password = "MNaW5zPf6_yGVe1lApEuvxFIrK1pEdakdvvtBq-ZaTo";
			Configuration.Default.AccessToken = "MNaW5zPf6_yGVe1lApEuvxFIrK1pEdakdvvtBq-ZaTo";
            Configuration.Default.Timeout = 1000;
        }
	}

	public class ConfigPreLoad
	{
		public static bool flagScenarioCollectExecuted;
		public static bool modeCollectPersistent = true;
		public static string csvDataDelimeter = ";";

		public static DataTable tableDgvExchange = new DataTable();
		public static DataTable tableDgvMethod = new DataTable();
		public static DataTable tableDgvParams = new DataTable();

		public static ClassDeribitApiParams.LastTradesByInstrumentAndTime oParamRequest { get; set; }
		public static string GetTableDgvData(DataTable table, string col1, string col1val, string col2)
		{
			string vOutput = (from DataRow dr in table.Rows
												where (string)dr[col1] == col1val
												select (string)dr[col2]).FirstOrDefault();
			return vOutput;
		}
		public static void SetTableDefaultParams()
		{
			tableDgvExchange.Columns.Add("ExchangeID", typeof(int));
			tableDgvExchange.Columns.Add("Enable", typeof(bool));
			tableDgvExchange.Columns.Add("Exchange", typeof(string));
			tableDgvExchange.Rows.Add(1, true, "Deribit");

			tableDgvMethod.Columns.Add("ApiMethodID", typeof(int));
			tableDgvMethod.Columns.Add("Enable", typeof(bool));
			tableDgvMethod.Columns.Add("ApiMethod", typeof(string));
			tableDgvMethod.Rows.Add(1, true, "/public/get_order_book");
			tableDgvMethod.Rows.Add(2, true, "/public/get_tradingview_chart_data");
			tableDgvMethod.Rows.Add(3, true, "/public/get_last_trades_by_instrument_and_time");

			tableDgvParams.Columns.Add("ParamID", typeof(int));
			tableDgvParams.Columns.Add("Key", typeof(string));
			tableDgvParams.Columns.Add("Value", typeof(string));
			tableDgvParams.Rows.Add(1, "file_save", "C:\\get_last_trades_by_instrument_and_time.csv");
			tableDgvParams.Rows.Add(1, "instrumentName", "BTC-PERPETUAL");
			tableDgvParams.Rows.Add(2, "startTimestamp", "0");
			tableDgvParams.Rows.Add(3, "endTimestamp", "1680395829000");
			tableDgvParams.Rows.Add(4, "count", "1000");
			tableDgvParams.Rows.Add(5, "includeOld", "true");
			tableDgvParams.Rows.Add(6, "sorting", "asc");
		}
		public static void GetTableDgvParamRequest()
		{
			//List<String> listTableDgvParams = tableDgvParams.AsEnumerable().Select(r => r.Field<string>(1)).ToList();
			//PropertyInfo[] properties = typeof(ClassDeribitApiParamsLastTradesByInstrumentAndTime).GetProperties();
			//foreach (PropertyInfo property in properties)
			//{
			//	property.SetValue(ApiParamsLastTradesByInstrumentAndTime, GetTableDgvData(tableDgvParams, "key", property.ToString(), "value"));
			//}
			oParamRequest = new ClassDeribitApiParams.LastTradesByInstrumentAndTime();
			oParamRequest.SetVal(
				GetTableDgvData(tableDgvParams, "key", "instrumentName", "value"),
				GetTableDgvData(tableDgvParams, "key", "startTimestamp", "value"),
				GetTableDgvData(tableDgvParams, "key", "endTimestamp", "value"),
				GetTableDgvData(tableDgvParams, "key", "count", "value"),
				GetTableDgvData(tableDgvParams, "key", "includeOld", "value"),
				GetTableDgvData(tableDgvParams, "key", "sorting", "value"));
		}
	}

	public class FileHandle
	{
		public bool exist;
		public Int64 length = 0;
		public bool created;

		public void Create(string vGetPathFileToSave)
		{
			try
			{
				if (File.Exists(vGetPathFileToSave))
				{
					exist = true;
					length = new FileInfo(vGetPathFileToSave).Length;
					created = false;
					return;
				}

				// Create the file, or overwrite if the file exists.
				using (FileStream fs = File.Create(vGetPathFileToSave))
				{
					byte[] info = new UTF8Encoding(true).GetBytes("");
					fs.Write(info, 0, info.Length);
				}
			}
			catch (Exception e)
			{
				MessageBox.Show(e.ToString());
				exist = false;
				created = false;
				return;
			}

			exist = true;
			created = true;
			return;
		}

		public static dynamic CsvReader(string vGetPathFileToSave)
		{
			TextReader reader = null;
			try
			{
				reader = new StreamReader(vGetPathFileToSave);
			}
			catch (Exception e)
			{
				MessageBox.Show(e.Message);
			}

			if (reader == null) return null;
			var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
			csv.Configuration.HasHeaderRecord = false;
			csv.Configuration.Delimiter = ConfigPreLoad.csvDataDelimeter;
			csv.Configuration.MissingFieldFound = null;
			return csv;
		}

		public static dynamic CsvWriter(string vGetPathFileToSave)
		{
			TextWriter writer = null;
			try { writer = new StreamWriter(vGetPathFileToSave, true, Encoding.UTF8); }
			catch (Exception e) { MessageBox.Show(e.Message); }

			if (writer == null) return null;
			var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);
			return csv;
		}

		public static bool CsvWriteTrades(CsvWriter csv, ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.Data obj)
		{
			csv.Configuration.Delimiter = ConfigPreLoad.csvDataDelimeter;
			csv.Configuration.ShouldQuote = (field, context) => false;
			try
			{
				foreach (ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.Trade trade in obj.result.trades)
				{
					csv.WriteField(ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.TradeOutput.NewRow(trade, ""));
					csv.NextRecord();
				}
				csv.Dispose();
				csv.Flush();
			}
			catch (Exception e) { return false; }

			return true;
		}
}
	public class GetApiResult { public static string ResultText { get; set; } }
	class Program
	{
		private static readonly DateTime Epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		private static object reqResult;

		// FIX THIS TIME
		// https://stackoverflow.com/questions/23381870/conversion-from-milliseconds-to-datetime-format/23381903
		internal static long ConvDateToStamp(DateTime vDateTime, bool addMs = false)
		{
			TimeSpan elapsedTime = vDateTime.ToUniversalTime() - Epoch;
			if (addMs)
				return (long)elapsedTime.TotalMilliseconds;
			else
				return (long)elapsedTime.TotalSeconds;
		}
		internal static string ConvStampToDateTimeMsString(long unixTimeStamp, string mode = "f")
		{
			// Unix timestamp is seconds past epoch
			System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);

			dtDateTime = Epoch.AddMilliseconds(unixTimeStamp);
			if (mode == "d")
				return dtDateTime.ToLocalTime().Date.ToString("d");
			if (mode == "t")
				return dtDateTime.ToLocalTime().ToString("HH:mm:ss.fff");
			if (mode == "s")
				return dtDateTime.ToLocalTime().ToString("dd.MM.yy HH:mm:ss.fff");

			return dtDateTime.ToLocalTime().ToString("dd.MM.yyyy HH:mm:ss.fff");
		}

		//public static string ConvStampToDateString(double unixTimeStamp, bool AddMS = false)
		//{
		//	string StampFraction= "";
		//	if (AddMS) {
		//		double StampNoMS = unixTimeStamp / 1000;
		//		StampFraction = Convert.ToString(unixTimeStamp / 1000).Split(',')[1];
		//		unixTimeStamp = Math.Truncate(StampNoMS);
		//	}
		//	System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
		//	dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToLocalTime();
		//	if (AddMS) { return dtDateTime.ToString() + " " + StampFraction + "ms"; } else { return dtDateTime.ToString(); }
		//}

		public static void TestApiGetTimeGet() // /public/get_time
		{
			var apiInstance = new SupportingApi(Configuration.Default);
			string tmp;
			Dictionary<string, string> DicRes;
			try
			{
				// Retrieves the current time (in milliseconds). This API endpoint can be used to check the clock skew between your software and Deribit's systems.
				Object result = apiInstance.PublicGetTimeGet();
				GetApiResult.ResultText = result.ToString();
				DicRes = JsonConvert.DeserializeObject<Dictionary<string, string>>(GetApiResult.ResultText);
				DicRes.TryGetValue("result", out tmp);
				GetApiResult.ResultText += "\r\n" + Program.ConvStampToDateTimeMsString(Convert.ToInt64(tmp));
			}
			catch (ApiException e)
			{
				var result = "Exception when calling " + MethodBase.GetCurrentMethod().Name + ":\r\n" +
				             e.Message + "Status Code:\r\n" + e.ErrorCode + "\r\n" + e.StackTrace;
				GetApiResult.ResultText = result.ToString();
				Console.WriteLine("Exception when calling MarketDataApi.PublicGetOrderBookGet: " + e.Message);
				Console.WriteLine("Status Code: " + e.ErrorCode);
				Console.WriteLine(e.StackTrace);
			}

		}
		public static void TestPublicGetOrderBookGet() // /public/get_order_book
		{
			var apiInstance = new MarketDataApi(Configuration.Default);
			var instrumentName = "BTC-PERPETUAL";
			var depth = 10;
			try
			{
				// Retrieves the order book, along with other market values for a given instrument.
				Object result = apiInstance.PublicGetOrderBookGet(instrumentName, depth);
				GetApiResult.ResultText = result.ToString();
			}
			catch (ApiException e)
			{
				var result = "Exception when calling " + MethodBase.GetCurrentMethod().Name + ":\r\n" +
				             e.Message + "Status Code:\r\n" + e.ErrorCode + "\r\n" + e.StackTrace;
				GetApiResult.ResultText = result.ToString();
				Console.WriteLine("Exception when calling MarketDataApi.PublicGetOrderBookGet: " + e.Message);
				Console.WriteLine("Status Code: " + e.ErrorCode);
				Console.WriteLine(e.StackTrace);
			}
		}
		public static void TestPublicGetTradingviewChartDataGet() // /public/get_tradingview_chart_data
		{
			var apiInstance = new MarketDataApi(Configuration.Default);
			var instrumentName = "BTC-PERPETUAL";
			var startTimestamp = 1536539522277; // long? | The earliest timestamp to return result for
			var endTimestamp = 1536569522277; // long? | The most recent timestamp to return result for
			var resolution = 1;
			try
			{
				// Publicly available market data used to generate a TradingView candle chart.
				Object result = apiInstance.PublicGetTradingviewChartDataGet(instrumentName, startTimestamp, endTimestamp, resolution);
				GetApiResult.ResultText = result.ToString();
			}
			catch (ApiException e)
			{
				var result = "Exception when calling " + MethodBase.GetCurrentMethod().Name + ":\r\n" + 
				         e.Message + "Status Code:\r\n" + e.ErrorCode + "\r\n" + e.StackTrace;
				GetApiResult.ResultText = result.ToString();
				Console.WriteLine("Exception when calling MarketDataApi.PublicGetOrderBookGet: " + e.Message);
				Console.WriteLine("Status Code: " + e.ErrorCode);
				Console.WriteLine(e.StackTrace);
			}
		}
		public static void TestPublicGetLastTradesByInstrumentAndTimeGet() // /public/get_last_trades_by_instrument_and_time
		{
			var apiInstance = new MarketDataApi(Configuration.Default);
			var instrumentName = "BTC-PERPETUAL";  // string | Instrument name
			var startTimestamp = 1536569522277;  // long? | The earliest timestamp to return result for
			var endTimestamp = 1536557522277;  // long? | The most recent timestamp to return result for
			var count = 56;  // int? | Number of requested items, default - `10` (optional) 
			var includeOld = true;  // bool? | Include trades older than 7 days, default - `false` (optional) 
			var sorting = "desc";  // string | Direction of results sorting (`default` value means no sorting, results will be returned in order in which they left the database) (optional) 

			try
			{
				// Retrieve the latest trades that have occurred for a specific instrument and within given time range.
				Object result = apiInstance.PublicGetLastTradesByInstrumentAndTimeGet(instrumentName, startTimestamp, endTimestamp, count, includeOld, sorting);
				GetApiResult.ResultText = result.ToString();
			}
			catch (ApiException e)
			{
				var result = "Exception when calling method: " + MethodBase.GetCurrentMethod().Name + ":\r\nMessage: " +
				             e.Message + "\r\nStatus Code: " + e.ErrorCode + "\r\nStackTrace: " + e.StackTrace;
				GetApiResult.ResultText = result.ToString();
				Console.WriteLine("Exception when calling MarketDataApi.PublicGetLastTradesByInstrumentAndTimeGet: " + e.Message);
				Console.WriteLine("Status Code: " + e.ErrorCode);
				Console.WriteLine(e.StackTrace);
			}
		}

		public static ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.Data ParseAPIRequestResult(object res)
		{
			ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.Data resObj = new ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.Data();
			try { resObj = JsonConvert.DeserializeObject<ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.Data>(res.ToString()); }
			catch (Exception e) { resObj.jsonrpc = "Exception when calling " + e.Message + "Status Code:\r\n" + e.StackTrace; }
			return resObj;
		}

		async public static void ScenarioCollect()
		{
			var vGetPathFileToSave = ConfigPreLoad.GetTableDgvData(ConfigPreLoad.tableDgvParams, "Key", "file_save", "Value");
			dynamic CSVFileRead, CSVFileWrite;
			FormMainLogAppend.EventHandler("collecting started, mode persistent: " + ConfigPreLoad.modeCollectPersistent.ToString().ToLowerInvariant());
			await Task.Run(() =>
			{
				ConfigPreLoad.GetTableDgvParamRequest();
				ConfigPreLoad.flagScenarioCollectExecuted = true;
				long currStartTimeStamp = 0;
				long currEndTimeStamp = 0;
				long prevTimeStamp = 0;
				// запрос последнего значения из файла
				FileHandle oFileHandle = new FileHandle();
				oFileHandle.Create(vGetPathFileToSave);
				if (!oFileHandle.exist) {
					FormMainLogAppend.EventHandler("error creating file " + vGetPathFileToSave + "\r\nAbort collecting");
					return;
				}

				if (oFileHandle.exist && oFileHandle.length > 0)
				{
					try
					{
						CSVFileRead = FileHandle.CsvReader(vGetPathFileToSave);
					}
					catch (Exception e)
					{
						FormMainLogAppend.EventHandler(e.ToString() + "\r\nabort collecting");
						return;
					}

					if (CSVFileRead == null)
					{
						FormMainLogAppend.EventHandler("error accessing file " + vGetPathFileToSave + "\r\nabort collecting");
						return;
					}
					using (CSVFileRead) { }

					ReverseLineReader CsvRecords = new ReverseLineReader(vGetPathFileToSave, Encoding.UTF8);
					string CsvLastR = string.Join("", CsvRecords.Take(1));
					CsvRecords.Dispose();
					using (CsvRecords) { }
					string[] arrCsvLastR = CsvLastR.Split(Convert.ToChar(";"));

					StoreDataLastTradesByInstrumentAndTime records = new StoreDataLastTradesByInstrumentAndTime(arrCsvLastR);

					try {
						currStartTimeStamp = ConvDateToStamp(DateTime.ParseExact(records.date + " " + records.timems, @"dd.MM.yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture), true);
					}
					catch (Exception e) {
						FormMainLogAppend.EventHandler(records.date + " " + records.timems +"\r\n" + e.Message.ToString() + "\r\ncorrupted data format, abort collecting");
						return;
					}
					FormMainLogAppend.EventHandler("found file " + vGetPathFileToSave + "\r\nlatest date: " + records.date + " " + records.timems + ", stamp: " + currStartTimeStamp.ToString());
				}
				else if (oFileHandle.created)
					FormMainLogAppend.EventHandler("file is created, proceed");
				else
					FormMainLogAppend.EventHandler("file is empty, proceed");

				if (currStartTimeStamp < ConfigPreLoad.oParamRequest.startTimestamp)
					currStartTimeStamp = ConfigPreLoad.oParamRequest.startTimestamp;
				if (currEndTimeStamp < ConfigPreLoad.oParamRequest.endTimestamp)
					currEndTimeStamp = ConfigPreLoad.oParamRequest.endTimestamp;

				if (currStartTimeStamp > currEndTimeStamp)
				{
					FormMainLogAppend.EventHandler(string.Format("timestamp range invalid ({0}, {1}), stop", currStartTimeStamp.ToString(), currEndTimeStamp.ToString()));
					return;
				}
				var oRequest = new ClassDeribitApiParams.LastTradesByInstrumentAndTime();
				JObject oResult;
				//string oResultTest;
				//IEnumerable<JToken> oResultParse; //IEnumerable<JProperty> oResultParse;
				ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.Data oResultParsed;
				//
				// Main collecting loop
				// 
				do
                {
                    reqResult = oRequest.Get(ConfigPreLoad.oParamRequest.instrumentName, currStartTimeStamp, currEndTimeStamp, ConfigPreLoad.oParamRequest.count, ConfigPreLoad.oParamRequest.includeOld, ConfigPreLoad.oParamRequest.sorting);
                    if (reqResult is string)
                    {
                        MessageBox.Show("Error during data receive!\r\n\r\n" + reqResult);
                        continue;
                    }
                    oResult = JObject.FromObject(reqResult);
					//oResultParse.Properties().Where(p => p.Name == "trades").ToList(); .Select(x => x.ToString()).ToArray();
					//oResultParse = oResult.SelectTokens("$..trades").Select(grp => grp.LastOrDefault()).Children();
					//oResultTest = Collection.GetKey(oResultParse); //.ToString());
					//oResultTest = JsonConvert.DeserializeObject<ClassDeribitApiParams.LastTradesByInstrumentAndTimeResult.Trade>(oResultParse.ToString());
					//return;
					oResultParsed = ParseAPIRequestResult(oResult);

					prevTimeStamp = currStartTimeStamp;
					currStartTimeStamp = oResultParsed.result.trades[oResultParsed.result.trades.Count()-1].timestamp + 1;
					FormMainLogAppend.EventHandler("r" + oResultParsed.result.trades.Count() + ": " + ConvStampToDateTimeMsString(prevTimeStamp, "s") + " - " + ConvStampToDateTimeMsString(currStartTimeStamp - 1,"s"));
					if (ConfigPreLoad.modeCollectPersistent)
					{
						Thread.Sleep(10);
						currEndTimeStamp = ConvDateToStamp(DateTime.Now, true);
					}
					else
					{
						if (oResultParsed.result.trades[999].timestamp >= ConfigPreLoad.oParamRequest.endTimestamp)
						{
							
							ConfigPreLoad.flagScenarioCollectExecuted = false;
						}
					}
					
					try { using (CSVFileWrite = FileHandle.CsvWriter(vGetPathFileToSave)) { FileHandle.CsvWriteTrades(CSVFileWrite, oResultParsed); } }
					catch (Exception e)
					{
						FormMainLogAppend.EventHandler("error accessing file " + vGetPathFileToSave + "\r\nabort collecting"); return;
					}

					if (CSVFileWrite == null)
						return;

				} while (ConfigPreLoad.flagScenarioCollectExecuted);
			});
			ScenarioStopCollect("finished");
			FormMainBtStopCollect.EventHandler();
		}
		public static void ScenarioStopCollect(string pState)
		{
			ConfigPreLoad.flagScenarioCollectExecuted = false;
			FormMainLogAppend.EventHandler(pState + " collecting process");
		}

		/// <summary>
		/// Главная точка входа для приложения.
		/// </summary>
		[STAThread]
    static void Main()
    {
      ConfigPreLoad.SetTableDefaultParams();
      ClassDeribitApiParams.SetApiConfig();

      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new FormMain());
    }
	}
}
